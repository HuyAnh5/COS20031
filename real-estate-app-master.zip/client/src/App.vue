<template>
  <div id="app">
    <!-- Header -->
    <header class="header">
      <div class="logo">Real Estate App</div>
      <nav class="nav">
        <router-link to="/">Home</router-link>
        <router-link to="/transactions">Transactions</router-link>
        <router-link to="/visualizer">Visualizer</router-link>
      </nav>
    </header>

    <!-- Main Content -->
    <router-view></router-view>
    <br>
    <br>
    <br>
    <!-- Footer -->
    <footer class="footer">
      <router-link to="/members" class="footer-link">Members Information</router-link>
      <p>© 2024 Real Estate App. All rights reserved.</p>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
/* General Styling */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Header */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #2c3e50;
  color: white;
  padding: 1em;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.logo {
  font-size: 1.5em;
  font-weight: bold;
}

.nav a {
  color: white;
  margin-right: 1em;
  text-decoration: none;
}

/* Space for fixed header */
#app {
  padding-top: 40px; /* Adjust based on header height */
  min-height: calc(100vh - 60px); /* Ensure content area is tall enough to push footer to the bottom */
  display: flex;
  flex-direction: column;
}

/* Main content area */
main {
  flex: 1;
}

/* Footer */
.footer {
  text-align: center;
  padding: 1em;
  background-color: #2c3e50;
  color: white;
  margin-top: auto; /* Push footer to the bottom of the container */
}

.footer a {
  color: white;
  margin: 0 1em;
  text-decoration: none;
}
</style>
