<template>
    <div>
      <h1>Register</h1>
      <form @submit.prevent="register">
        <div>
          <label for="email">Email:</label>
          <input type="email" v-model="email" required>
        </div>
        <div>
          <label for="password">Password:</label>
          <input type="password" v-model="password" required>
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        email: '',
        password: '',
      };
    },
    methods: {
        async register() {
            try {
                const response = await fetch('http://localhost:3000/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email: this.email, password: this.password })
                });

                if (response.ok) {
                alert('Registration successful');
                console.log(response.body);
                } else {
                alert('Registration failed');
                }
            } catch (error) {
                alert('Registration failed');
            }
            }
    },
  };
  </script>
  
  <style>
  /* Add your styles here */
  </style>
  