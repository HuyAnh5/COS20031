<template>
    <div class="members-info">
      <h1>Members Information</h1>
      <br>
      <div class="members-list">
        <div class="member-card" v-for="member in members" :key="member.name">
          <h2>{{ member.name }}</h2>
          <p><strong>Role:</strong> {{ member.role }}</p>
          <p>{{ member.description }}</p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        members: [
          {
            name: "Nguyen Huy Anh",
            role: "Project Manager + Leader",
            description: "Oversees project management and team coordination."
          },
          {
            name: "Nguyen Dang Khanh Toan",
            role: "Lead Programmer",
            description: "Specializes in backend development and API creation."
          },
          {
            name: "Tran Minh Dung",
            role: "Front-end Developer",
            description: "Focuses on crafting user-friendly interfaces."
          },
          {
            name: "Nguyen Dinh Phu",
            role: "Confluence Designer",
            description: "Manages project documentation and stakeholder communication."
          },
          {
            name: "Do Thanh Nghia",
            role: "Front-end Developer",
            description: "Designs interactive and responsive UIs."
          }
        ]
      };
    }
  };
  </script>
  
  <style scoped>
  .members-info {
    padding: 2em;
    text-align: center;
  }
  
  .members-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 2em;
  }
  
  .member-card {
    background-color: #f4f4f4;
    border-radius: 8px;
    padding: 1.5em;
    width: 250px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: left;
  }
  
  .member-card h2 {
    margin-top: 0;
  }
  
  .member-card p {
    margin: 0.5em 0;
  }
  </style>
  