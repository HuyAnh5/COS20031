<template>
  <div class="chart-container">
    <div ref="rentChartRef" class="chart"></div>
    <div ref="saleChartRef" class="chart"></div>
  </div>
</template>

<script>
import * as d3 from 'd3';
import axios from 'axios';
import { ref, watch, onMounted } from 'vue';

export default {
  name: 'LineChart',
  props: {
    selectedProperty: {
      type: Object,
      default: null
    }
  },
  setup(props) {
    const rentChartRef = ref(null);
    const saleChartRef = ref(null);
    const transactions = ref([]);

    const fetchTransactions = async () => {
      try {
        const res = await axios.get('http://localhost:3300/transactions');
        console.log('Fetched transactions:', res.data);
        transactions.value = res.data;
        updateCharts();
      } catch (error) {
        console.error('Error fetching transactions:', error);
      }
    };

    const updateCharts = () => {
      const filteredTransactions = props.selectedProperty
        ? transactions.value.filter(t => t.property_id === props.selectedProperty.property_id)
        : transactions.value;
      drawCharts(filteredTransactions);
    };

    const drawCharts = (data) => {
      // Separate data into rent and sale transactions
      const rentData = data.filter(d => d.transaction_type === 'Rent').map(d => ({
        date: new Date(d.start_date),
        price: d.price,
        info: d
      }));

      const saleData = data.filter(d => d.transaction_type === 'Sale').map(d => ({
        date: new Date(d.start_date),
        price: d.price,
        info: d
      }));

      console.log('Rent Data:', rentData);
      console.log('Sale Data:', saleData);

      drawChart(rentChartRef.value, rentData, 'Rent Transactions');
      drawChart(saleChartRef.value, saleData, 'Sale Transactions');
    };

    const drawChart = (chartContainer, data, chartTitle) => {
      const margin = { top: 20, right: 30, bottom: 30, left: 40 };
      const width = 800 - margin.left - margin.right;
      const height = 400 - margin.top - margin.bottom;

      // Clear any existing chart
      d3.select(chartContainer).selectAll('*').remove();

      const svg = d3.select(chartContainer)
        .append('svg')
        .attr('width', width + margin.left + margin.right)
        .attr('height', height + margin.top + margin.bottom)
        .append('g')
        .attr('transform', `translate(${margin.left},${margin.top})`);

      const x = d3.scaleTime()
        .domain(d3.extent(data, d => d.date))
        .range([0, width]);

      const y = d3.scaleLinear()
        .domain([0, d3.max(data, d => d.price)])
        .nice()
        .range([height, 0]);

      svg.append('g')
        .attr('transform', `translate(0,${height})`)
        .call(d3.axisBottom(x).ticks(width / 80).tickSizeOuter(0));

      svg.append('g')
        .call(d3.axisLeft(y));

      svg.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', 'steelblue')
        .attr('stroke-width', 1.5)
        .attr('d', d3.line()
          .x(d => x(d.date))
          .y(d => y(d.price)));

      // Add nodes
      svg.selectAll('.node')
        .data(data)
        .enter().append('circle')
        .attr('class', 'node')
        .attr('cx', d => x(d.date))
        .attr('cy', d => y(d.price))
        .attr('r', 5)
        .attr('fill', 'red')
        .on('mouseover', (event, d) => {
          tooltip.transition()
            .duration(200)
            .style('opacity', .9);
          tooltip.html(`<strong>Transaction ID:</strong> ${d.info.transaction_id}<br>
                        <strong>Price:</strong> $${d.price}<br>
                        <strong>Start Date:</strong> ${d.info.start_date}<br>
                        <strong>End Date:</strong> ${d.info.end_date}<br>
                        <strong>Party:</strong> ${d.info.party_names}`)
            .style('left', (event.pageX + 5) + 'px')
            .style('top', (event.pageY - 28) + 'px');
        })
        .on('mouseout', (d) => {
          tooltip.transition()
            .duration(500)
            .style('opacity', 0);
        });

      // Add chart title
      svg.append('text')
        .attr('x', width / 2)
        .attr('y', -10)
        .attr('text-anchor', 'middle')
        .style('font-size', '16px')
        .style('text-decoration', 'underline')
        .text(chartTitle);
    };

    const tooltip = d3.select('body').append('div')
      .attr('class', 'tooltip')
      .style('position', 'absolute')
      .style('text-align', 'left')
      .style('width', '150px')
      .style('height', 'auto')
      .style('padding', '10px')
      .style('font', '12px sans-serif')
      .style('background', 'lightsteelblue')
      .style('border', '0px')
      .style('border-radius', '8px')
      .style('pointer-events', 'none')
      .style('opacity', 0);

    onMounted(() => {
      fetchTransactions();
    });

    watch(() => props.selectedProperty, updateCharts);

    return {
      rentChartRef,
      saleChartRef,
    };
  },
};
</script>

<style scoped>
.chart-container {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.chart {
  width: 100%;
  height: 400px;
  border: 1px solid red; /* Add border to see the div */
  margin-bottom: 20px;
}

.tooltip {
  position: absolute;
  text-align: left;
  width: 150px;
  height: auto;
  padding: 10px;
  font: 12px sans-serif;
  background: lightsteelblue;
  border: 0px;
  border-radius: 8px;
  pointer-events: none;
  opacity: 0;
}
</style>
