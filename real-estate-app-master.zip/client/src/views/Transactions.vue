<template>
  <div class="container mt-4">
    <div class="row">
      <!-- Filters on the left -->
       <h1>Transition</h1>
      <div class="col-lg-3 sticky-filter">
        <div class="mb-3">
          <input 
            type="text" 
            v-model="searchQuery" 
            @input="onFilterChange" 
            class="form-control" 
            placeholder="Search transactions..."
          />
        </div>
        <div class="mb-3">
          <label>Type:</label><br>
          <div>
            <input type="radio" id="sale" value="Sale" v-model="transactionType" @change="onFilterChange">
            <label for="sale">Sale</label>
          </div>
          <div>
            <input type="radio" id="rental" value="Rent" v-model="transactionType" @change="onFilterChange">
            <label for="rental">Rent</label>
          </div>
          <div>
            <input type="radio" id="lease" value="Lease" v-model="transactionType" @change="onFilterChange">
            <label for="lease">Lease</label>
          </div>
          <div>
            <input type="radio" id="all" value="" v-model="transactionType" @change="onFilterChange">
            <label for="all">All</label>
          </div>
        </div>
        <div class="mb-3">
          <label for="startDate">Start Date:</label>
          <input id="startDate" type="date" v-model="startDate" class="form-control" @change="onFilterChange">
        </div>
        <div class="mb-3">
          <label for="endDate">End Date:</label>
          <input id="endDate" type="date" v-model="endDate" class="form-control" @change="onFilterChange">
        </div>
        <div class="mb-3">
          <button type="button" class="btn btn-secondary" @click="clearFilters">Clear Filters</button>
        </div>
      </div>

      <!-- Table on the right -->
      <div class="col-lg-9">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>Property Name</th>
              <th>Transaction Type</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Price</th>
              <th>Parties</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="transaction in sortedTransactions" :key="transaction.transaction_id" :class="transactionTypeClass(transaction.transaction_type)">
              <td>{{ transaction.property_name }}</td>
              <td>{{ transaction.transaction_type }}</td>
              <td>{{ formatDate(transaction.start_date) }}</td>
              <td>{{ formatDate(transaction.end_date) }}</td>
              <td>{{ transaction.price }}</td>
              <td>
                <ul>
                  <li v-for="(party, index) in getParties(transaction)" :key="index">
                    {{ party.name }} ({{ party.type }})
                  </li>
                </ul>
              </td>
              <td>
                <button type="button" class="btn btn-primary me-2" @click="showDetails(transaction)">Details</button>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="d-flex justify-content-between align-items-center">
          <paginate
            ref="paginate"
            :page-count="pageCount"
            :page-range="3"
            :margin-pages="1"
            :click-handler="changePage"
            :prev-text="'Prev'"
            :next-text="'Next'"
            :container-class="'pagination justify-content-center'"
            :page-class="'page-item'"
            :page-link-class="'page-link'"
            :prev-class="'page-item'"
            :prev-link-class="'page-link'"
            :next-class="'page-item'"
            :next-link-class="'page-link'"
            :active-class="'active'"
          >
          </paginate>
          <div class="find-page">
            <input type="number" v-model.number="findPageNumber" class="form-control d-inline-block w-auto" placeholder="Page #" min="1" :max="pageCount">
            <button class="btn btn-primary ms-2" @click="goToPage">Find Page</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Background overlay -->
    <div v-if="selectedTransaction || isEditing || isAdding" class="modal-overlay"></div>

    <!-- Property Details Modal -->
    <div v-if="selectedTransaction" class="modal fade show" tabindex="-1" style="display: block;" aria-labelledby="detailsModalLabel">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="detailsModalLabel">Transaction Details</h5>
            <button type="button" class="btn-close" @click="closeModal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p><strong>Transaction ID:</strong> {{ selectedTransaction.transaction_id }}</p>
            <p><strong>Transaction Type:</strong> {{ selectedTransaction.transaction_type }}</p>
            <p><strong>Property ID:</strong> {{ selectedTransaction.property_id }}</p>
            <p><strong>Property Name:</strong> {{ selectedTransaction.property_name }}</p>
            <p><strong>Total Sqm:</strong> {{ selectedTransaction.total_sqm }}</p>
            <p><strong>Bedrooms:</strong> {{ selectedTransaction.number_bedroom }}</p>
            <p><strong>Bathrooms:</strong> {{ selectedTransaction.number_bathroom }}</p>
            <p><strong>Amenity:</strong> {{ selectedTransaction.amenity }}</p>
            <p><strong>Street Address:</strong> {{ selectedTransaction.street_address }}</p>
            <p><strong>Room Number:</strong> {{ selectedTransaction.room_number }}</p>
            <p><strong>City:</strong> {{ selectedTransaction.city_name }}</p>
            <p><strong>Region:</strong> {{ selectedTransaction.region_name }}</p>
            <p><strong>Party Information:</strong></p>
            <ul>
              <li v-for="(party, index) in getParties(selectedTransaction)" :key="index">
                {{ party.name }} ({{ party.type }})
              </li>
            </ul>
            <p><strong>Start Date:</strong> {{ formatDate(selectedTransaction.start_date) }}</p>
            <p><strong>End Date:</strong> {{ formatDate(selectedTransaction.end_date) }}</p>
            <p><strong>Price:</strong> {{ selectedTransaction.price }}</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeModal">Close</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Add Modal -->
    <div v-if="isAdding" class="modal fade show" tabindex="-1" style="display: block;" aria-labelledby="addModalLabel">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="addModalLabel">Add New Entry</h5>
            <button type="button" class="btn-close" @click="closeModal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>
              <label for="addTransactionId">Name:</label>
              <input id="addTransactionId" type="text" v-model="newTransaction.name" class="form-control">
            </p>
            <p>
              <label for="addType">Transaction Type:</label>
              <select id="addType" v-model="newTransaction.transaction_type" class="form-select">
                <option value="Sale">Sale</option>
                <option value="Rent">Rent</option>
                <option value="Lease">Lease</option>
              </select>
            </p>
            <p>
              <label for="addPropertyId">Property ID:</label>
              <input id="addPropertyId" type="text" v-model="newTransaction.property_id" class="form-control">
            </p>
            <p>
              <label for="addStartDate">Start Date:</label>
              <input id="addStartDate" type="date" v-model="newTransaction.start_date" class="form-control">
            </p>
            <p>
              <label for="addEndDate">End Date:</label>
              <input id="addEndDate" type="date" v-model="newTransaction.end_date" class="form-control">
            </p>
            <p>
              <label for="addPrice">Price:</label>
              <input id="addPrice" type="number" v-model="newTransaction.price" class="form-control">
            </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeModal">Cancel</button>
            <button type="button" class="btn btn-success" @click="addNew">Add</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <div v-if="isEditing" class="modal fade show" tabindex="-1" style="display: block;" aria-labelledby="editModalLabel">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel">Edit Transaction</h5>
            <button type="button" class="btn-close" @click="closeModal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p>
              <label for="editTransactionId">Name:</label>
              <input id="editTransactionId" type="text" v-model="selectedTransaction.name" class="form-control" >
            </p>
            <p>
              <label for="editType">Transaction Type:</label>
              <select id="editType" v-model="selectedTransaction.transaction_type" class="form-select">
                <option value="Sale">Sale</option>
                <option value="Rent">Rent</option>
                <option value="Lease">Lease</option>
              </select>
            </p>
            <p>
              <label for="editPropertyId">Property ID:</label>
              <input id="editPropertyId" type="text" v-model="selectedTransaction.property_id" class="form-control">
            </p>
            <p>
              <label for="editStartDate">Start Date:</label>
              <input id="editStartDate" type="date" v-model="selectedTransaction.start_date" class="form-control">
            </p>
            <p>
              <label for="editEndDate">End Date:</label>
              <input id="editEndDate" type="date" v-model="selectedTransaction.end_date" class="form-control">
            </p>
            <p>
              <label for="editPrice">Price:</label>
              <input id="editPrice" type="number" v-model="selectedTransaction.price" class="form-control">
            </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" @click="closeModal">Cancel</button>
            <button type="button" class="btn btn-success" @click="updateTransaction">Save Changes</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Paginate from 'vuejs-paginate-next';

export default {
  components: {
    paginate: Paginate,
  },
  data() {
    return {
      transactions: [],
      currentPage: 1,
      itemsPerPage: 100,
      totalTransactions: 0,
      searchQuery: '',
      transactionType: '',
      startDate: '',
      endDate: '',
      findPageNumber: null,
      selectedTransaction: null,
      isEditing: false,
      isAdding: false,
      newTransaction: {
        transaction_id: '',
        name: '',
        transaction_type: '',
        property_id: '',
        start_date: '',
        end_date: '',
        price: '',
      },
      sortColumn: '',
      sortDirection: 'asc'
    };
  },
  computed: {
    pageCount() {
      return Math.ceil(this.totalTransactions / this.itemsPerPage);
    },
    sortedTransactions() {
      return this.filteredTransactions.sort((a, b) => {
        let modifier = this.sortDirection === 'asc' ? 1 : -1;
        if (this.sortColumn) {
          return a[this.sortColumn].localeCompare(b[this.sortColumn]) * modifier;
        }
        return 0;
      });
    },
    filteredTransactions() {
      const searchQuery = this.searchQuery.toLowerCase();
      return this.transactions.filter(transaction => {
        const matchesSearch = Object.keys(transaction).some(key => String(transaction[key]).toLowerCase().includes(searchQuery));
        const matchesType = this.transactionType ? transaction.transaction_type === this.transactionType : true;
        const matchesStartDate = this.startDate === "" || transaction.start_date >= this.startDate;
        const matchesEndDate = this.endDate === "" || transaction.end_date <= this.endDate;
        return matchesSearch && matchesType && matchesStartDate && matchesEndDate;
      });
    }
  },
  methods: {
    transactionTypeClass(type) {
      return {
        'table-success': type === 'Sale',
        'table-warning': type === 'Rent',
        'table-info': type === 'Lease',
      };
    },
    async fetchTransactions() {
      try {
        const res = await axios.get('http://localhost:3300/transactions', {
          params: {
            page: this.currentPage,
            limit: this.itemsPerPage,
            search: this.searchQuery,
            type: this.transactionType,
            startDate: this.startDate || null,
            endDate: this.endDate || null
          }
        });
        this.transactions = res.data;
        console.log(res.data);
        this.fetchTotalTransactions();
      } catch (error) {
        console.error('Error fetching transactions:', error);
      }
    },
    async fetchTotalTransactions() {
      try {
        const res = await axios.get('http://localhost:3300/transactions/count');
        this.totalTransactions = res.data;
      } catch (error) {
        console.error('Error fetching transaction count:', error);
      }
    },
    changePage(pageNum) {
      this.currentPage = pageNum;
      this.fetchTransactions();
    },
    formatDate(dateString) {
      const options = { year: 'numeric', month: 'numeric', day: 'numeric' };
      return new Date(dateString).toLocaleDateString('en-US', options);
    },
    goToPage() {
      if (this.findPageNumber > 0 && this.findPageNumber <= this.pageCount) {
        this.changePage(this.findPageNumber);
      }
    },
    async handleDelete(transaction_id) {
      try {
        await axios.delete(`http://localhost:3300/transactions/${transaction_id}`);
        this.fetchTransactions();
      } catch (err) {
        console.error('Error deleting transaction:', err.response ? err.response.data : err);
      }
    },
    onFilterChange() {
      this.currentPage = 1;
      this.$refs.paginate.selected = 1;
      this.fetchTransactions();
    },
    onSortChange() {
      this.currentPage = 1;
      this.fetchTransactions();
    },
    async showDetails(transaction) {
      this.selectedTransaction = transaction;
    },
    showAddModal() {
      this.isAdding = true;
    },
    showEditModal(transaction) {
      this.selectedTransaction = { ...transaction };
      this.isEditing = true;
    },
    closeModal() {
      this.selectedTransaction = null;
      this.isEditing = false;
      this.isAdding = false;
    },
    async addNew() {
      try {
        await axios.post('http://localhost:3300/transactions', this.newTransaction);
        this.fetchTransactions();
        this.newTransaction = { transaction_id: '', name: '', transaction_type: '', property_id: '', start_date: '', end_date: '', price: '' };
        this.closeModal();
      } catch (error) {
        console.error('Error adding new transaction:', error.response ? error.response.data : error);
      }
    },
    async updateTransaction() {
      try {
        await axios.put(`http://localhost:3300/transactions/${this.selectedTransaction.transaction_id}`, this.selectedTransaction);
        this.fetchTransactions();
        this.selectedTransaction = null;
        this.isEditing = false;
      } catch (error) {
        console.error('Error updating transaction:', error.response ? error.response.data : error);
      }
    },
    getParties(transaction) {
      const names = transaction.party_names ? transaction.party_names.split(', ') : [];
      const types = transaction.party_types ? transaction.party_types.split(', ') : [];
      return names.map((name, index) => ({
        name,
        type: types[index]
      }));
    },
    clearFilters() {
      this.searchQuery = '';
      this.transactionType = '';
      this.startDate = '';
      this.endDate = '';
      this.onFilterChange();
    }
  },
  created() {
    this.fetchTransactions();
    this.fetchTotalTransactions();
  }
};
</script>

<style scoped>
.sticky-filter {
  position: -webkit-sticky;
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
  padding-top: 20px;
  background-color: #f8f9fa;
  border-right: 1px solid #dee2e6;
}

.table {
  width: 100%;
  margin-bottom: 1rem;
  color: #212529;
}

.table th,
.table td {
  padding: 0.75rem;
  vertical-align: top;
  border-top: 1px solid #dee2e6;
}

.table thead th {
  vertical-align: bottom;
  border-bottom: 2px solid #dee2e6;
}

.table tbody + tbody {
  border-top: 2px solid #dee2e6;
}

.table .table {
  background-color: #fff;
}

.pagination {
  display: flex;
  padding-left: 0;
  list-style: none;
  border-radius: 0.25rem;
}

.page-item {
  margin: 0 0.25rem;
}

.page-link {
  position: relative;
  display: block;
  padding: 0.5rem 0.75rem;
  margin-left: -1px;
  line-height: 1.25;
  color: #007bff;
  background-color: #fff;
  border: 1px solid #dee2e6;
}

.page-link:hover {
  color: #0056b3;
  text-decoration: none;
  background-color: #e9ecef;
  border-color: #dee2e6;
}

.page-item.active .page-link {
  z-index: 1;
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}

.page-item.disabled .page-link {
  color: #6c757d;
  pointer-events: none;
  background-color: #fff;
  border-color: #dee2e6;
}

.find-page {
  display: flex;
  align-items: center;
}

.table-success {
  background-color: #d4edda !important;
}

.table-warning {
  background-color: #fff3cd !important;
}

.table-info {
  background-color: #d1ecf1 !important;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1050; /* Ensure it appears above other content but below modals */
}
</style>
