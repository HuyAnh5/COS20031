<template>
  <div class="homepage">
    <!-- Hero Section -->
    <section class="hero">
      <h1>Welcome to Real Estate App - Your Real Estate Transaction Manager</h1>
      <p>Manage and analyze your real estate transactions with ease.</p>
      <div class="cta-buttons">
        <router-link to="/transactions" class="btn btn-view-transactions">View Transactions</router-link>
        <router-link to="/visualizer" class="btn btn-view-transactions">View Visualizer</router-link>
      </div>
    </section>

    <!-- Main Content -->
    <main class="main-content">
      <section class="dashboard-overview">
        <div class="dashboard-item">
          <h2>Total Transactions</h2>
          <p>{{ totalTransactions }}</p>
        </div>
        <div class="dashboard-item">
          <h2>Recent Transactions</h2>
          <ul>
            <li v-for="transaction in recentTransactions" :key="transaction.id">
              {{ transaction.description }}
            </li>
          </ul>
        </div>
      </section>
    </main>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      totalTransactions: 0,
      recentTransactions: [
        { id: 1, description: "Transaction 1" },
        { id: 2, description: "Transaction 2" },
        // Add more example transactions as needed
      ],
    };
  },
  methods: {
    async fetchTransactionCount() {
      try {
        const res = await axios.get('http://localhost:3300/transactions/count');
        this.totalTransactions = res.data;
      } catch (error) {
        console.error('Error fetching transaction count:', error);
      }
    },
  },
  created() {
    this.fetchTransactionCount();
  },
};
</script>

<style scoped>
/* General Styling */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Hero Section */
.hero {
  text-align: center;
  padding: 2em 0;
  background-color: #ecf0f1;
}

.cta-buttons {
  margin-top: 1.5em;
}

.btn-view-transactions {
  background-color: #597284;
  color: white;
  padding: 0.75em 1.5em;
  font-size: 1.2em;
  font-weight: bold;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  text-decoration: none;
  transition: background-color 0.3s ease;
  margin: 0 10px; /* Adjusted to add spacing */
}

.btn-view-transactions:hover {
  background-color: #1090e5;
}

/* Main Content */
.main-content {
  padding: 2em;
}

.dashboard-overview {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.dashboard-item {
  background-color: #f4f4f4;
  margin: 1em;
  padding: 1em;
  border-radius: 5px;
  width: 45%;
}
</style>
