<template>
  <div class="container mt-4">
    <h1>Price Fluctuation Visualizer</h1>
    <div class="layout">
      <div class="filter">
        <h2>Properties</h2>
        <table>
          <thead>
            <tr>
              <th>Property Name</th>
              <th>City</th>
              <th>Region</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="property in properties" :key="property.property_id" @click="selectProperty(property)">
              <td>{{ property.property_name }}</td>
              <td>{{ property.city_name }}</td>
              <td>{{ property.region_name }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="charts">
        <line-chart :selected-property="selectedProperty"></line-chart>
      </div>
    </div>
  </div>
</template>

<script>
import LineChart from './LineChart.vue';
import axios from 'axios';
import { ref, onMounted } from 'vue';

export default {
  name: 'Visualizer',
  components: {
    LineChart,
  },
  setup() {
    const properties = ref([]);
    const selectedProperty = ref(null);

    const fetchProperties = async () => {
      try {
        const res = await axios.get('http://localhost:3300/transactions');
        console.log('Fetched properties:', res.data);
        // Extract unique properties
        const uniqueProperties = res.data.reduce((acc, transaction) => {
          if (!acc.some(p => p.property_id === transaction.property_id)) {
            acc.push({
              property_id: transaction.property_id,
              property_name: transaction.property_name,
              city_name: transaction.city_name,
              region_name: transaction.region_name,
            });
          }
          return acc;
        }, []);
        properties.value = uniqueProperties;
      } catch (error) {
        console.error('Error fetching properties:', error);
      }
    };

    const selectProperty = (property) => {
      selectedProperty.value = property;
    };

    onMounted(() => {
      fetchProperties();
    });

    return {
      properties,
      selectedProperty,
      selectProperty,
    };
  },
};
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
}

.layout {
  display: flex;
}

.filter {
  flex: 1;
  margin-right: 20px;
}

.charts {
  flex: 3;
}

.filter table {
  width: 100%;
  border-collapse: collapse;
}

.filter table th,
.filter table td {
  border: 1px solid #ddd;
  padding: 8px;
}

.filter table tr:hover {
  background-color: #f1f1f1;
  cursor: pointer;
}
</style>
