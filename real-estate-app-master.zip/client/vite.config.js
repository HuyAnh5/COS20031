import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath } from 'node:url'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    watch: {
      usePolling: true, // This can help in environments where file system watching is unreliable
    },
    hmr: {
      overlay: false, // Disable the error overlay to check if it affects reloading
    },
  },
})
