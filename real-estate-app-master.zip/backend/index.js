import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import { promises as fs } from "fs";
import pkg from "pg";

const { Pool } = pkg;

const app = express();
app.use(cors());
app.use(express.json());

const db = new Pool({
  user: 'admin',
  host: 'asia-east1.184b8e94-a319-4264-b326-2fca35dc2fb4.gcp.ybdb.io',
  database: 'yugabyte',
  password: 'XQngPMG9Zius9zwD9Exn72iSXuy3bH',
  port: 5433,
  ssl: {
    rejectUnauthorized: true,
    ca: await fs.readFile('./root.crt', 'utf-8')
  }
});

const JWT_SECRET = 'your_jwt_secret_key';

const authenticateToken = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

app.get("/", (req, res) => {
  res.json("Hello, this is the backend");
});

app.get("/transactions", async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 100;
  const offset = (page - 1) * limit;
  const search = req.query.search || '';
  const type = req.query.type || null;
  const startDate = req.query.startDate || null;
  const endDate = req.query.endDate || null;

  const searchQuery = `%${search}%`;

  let q = `
    SELECT 
      t.transaction_id,
      t.transaction_type,
      t.start_date,
      t.end_date,
      t.price,
      p.property_id,
      p.name AS property_name,
      p.total_sqm,
      p.number_bedroom,
      p.number_bathroom,
      p.amenity,
      a.address_id,
      a.street_address,
      a.room_number,
      c.city_id,
      c.city_name,
      r.region_id,
      r.region_name,
      string_agg(tp.transaction_party_id::text, ', ' ORDER BY tp.transaction_party_id) AS transaction_party_ids,
      string_agg(tp.type, ', ' ORDER BY tp.transaction_party_id) AS party_types,
      string_agg(pt.party_id::text, ', ' ORDER BY tp.transaction_party_id) AS party_ids,
      string_agg(pt.nature, ', ' ORDER BY tp.transaction_party_id) AS party_natures,
      string_agg(pt.name, ', ' ORDER BY tp.transaction_party_id) AS party_names
    FROM 
      transactions t
    JOIN 
      properties p ON t.property_id = p.property_id
    JOIN 
      address a ON p.address_id = a.address_id
    JOIN 
      city c ON a.city_id = c.city_id
    JOIN 
      region r ON a.region_id = r.region_id
    JOIN 
      transaction_parties tp ON t.transaction_id = tp.transaction_id
    JOIN 
      parties pt ON tp.party_id = pt.party_id
    WHERE 
      (t.transaction_id::text LIKE $1 OR 
      t.transaction_type::text LIKE $1 OR 
      t.property_id::text LIKE $1 OR 
      t.start_date::text LIKE $1 OR 
      t.end_date::text LIKE $1 OR 
      t.price::text LIKE $1 OR
      p.name::text LIKE $1 OR
      a.street_address::text LIKE $1 OR
      c.city_name::text LIKE $1 OR
      r.region_name::text LIKE $1 OR
      pt.name::text LIKE $1)
  `;

  const queryParams = [searchQuery];

  if (type) {
    q += ` AND t.transaction_type = $2`;
    queryParams.push(type);
  }

  if (startDate) {
    q += ` AND t.start_date >= $${queryParams.length + 1}`;
    queryParams.push(startDate);
  }

  if (endDate) {
    q += ` AND t.end_date <= $${queryParams.length + 1}`;
    queryParams.push(endDate);
  }

  q += ` GROUP BY t.transaction_id, p.property_id, a.address_id, c.city_id, r.region_id
         ORDER BY t.transaction_id ASC 
         LIMIT $${queryParams.length + 1} 
         OFFSET $${queryParams.length + 2}`;
  queryParams.push(limit, offset);

  console.log('Executing query:', q);
  console.log('With parameters:', queryParams);

  try {
    const { rows } = await db.query(q, queryParams);
    res.json(rows);
  } catch (err) {
    console.error('Error executing query', err.message, err.stack);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

app.get("/transactions/count", async (req, res) => {
  const q = "SELECT COUNT(*) as total FROM transactions";
  try {
    const { rows } = await db.query(q);
    res.json(rows[0].total);
  } catch (err) {
    console.error('Error executing query', err.message, err.stack);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

app.post("/transactions", async (req, res) => {
  const { transaction_id, name, transaction_type, property_id, start_date, end_date, price } = req.body;
  const q = "INSERT INTO transactions (transaction_id, name, transaction_type, property_id, start_date, end_date, price) VALUES ($1, $2, $3, $4, $5, $6, $7)";
  const values = [transaction_id, name, transaction_type, property_id, start_date, end_date, price];

  try {
    await db.query(q, values);
    res.json("Transaction has been added successfully!");
  } catch (err) {
    console.error('Error executing query', err.message, err.stack);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

app.delete("/transactions/:id", async (req, res) => {
  const transaction_id = req.params.id;
  const q = "DELETE FROM transactions WHERE transaction_id = $1";

  try {
    await db.query(q, [transaction_id]);
    res.json("Transaction has been deleted successfully!");
  } catch (err) {
    console.error('Error executing query', err.message, err.stack);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

app.put("/transactions/:id", async (req, res) => {
  const transaction_id = req.params.id;
  const { name, transaction_type, property_id, start_date, end_date, price } = req.body;
  const q = "UPDATE transactions SET name = $1, transaction_type = $2, property_id = $3, start_date = $4, end_date = $5, price = $6 WHERE transaction_id = $7";
  const values = [name, transaction_type, property_id, start_date, end_date, price, transaction_id];

  try {
    await db.query(q, values);
    res.json("Transaction has been updated successfully!");
  } catch (err) {
    console.error('Error executing query', err.message, err.stack);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

app.get("/properties/:id", async (req, res) => {
  const property_id = req.params.id;
  const q = "SELECT * FROM properties WHERE property_id = $1";

  try {
    const { rows } = await db.query(q, [property_id]);
    if (rows.length > 0) {
      res.json(rows[0]);
    } else {
      res.status(404).json({ message: 'Property not found' });
    }
  } catch (err) {
    console.error('Error executing query', err.message, err.stack);
    res.status(500).json({ error: 'Internal Server Error', details: err.message });
  }
});

app.listen(3300, () => {
  console.log("Connected to backend!!");
});
